#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <iomanip>
#include <algorithm>
#include <ctime>

using namespace std;

// Structure to represent a song
struct Song
{
    string title;
    string artist;
    string album;
    int year;
    int trackNumber;
};

// Function to display a colored message in the console (ANSI escape codes)
void colorPrint(const string &message, int colorCode)
{
    cout << "\033[" << colorCode << "m" << message << "\033[0m";
}

// Function to load songs from the data file
vector<Song> loadSongs(const string &filename)
{
    vector<Song> songs;
    ifstream file(filename);

    if (file.is_open())
    {
        string line;
        while (getline(file, line))
        {
            // Extract song data from the line
            // Assuming data is separated by commas
            size_t pos = line.find(',');
            string title = line.substr(0, pos);
            line = line.substr(pos + 1);

            pos = line.find(',');
            string artist = line.substr(0, pos);
            line = line.substr(pos + 1);

            pos = line.find(',');
            string album = line.substr(0, pos);
            line = line.substr(pos + 1);

            pos = line.find(',');
            int year = stoi(line.substr(0, pos));
            line = line.substr(pos + 1);

            int trackNumber = stoi(line);

            // Create a Song object and add it to the vector
            Song song = {title, artist, album, year, trackNumber};
            songs.push_back(song);
        }
        file.close();
    }
    return songs;
}

// Function to save songs to the data file
void saveSongs(const string &filename, const vector<Song> &songs)
{
    ofstream file(filename);

    if (file.is_open())
    {
        for (const Song &song : songs)
        {
            file << song.title << "," << song.artist << "," << song.album << ","
                 << song.year << "," << song.trackNumber << endl;
        }
        file.close();
    }
}

// Function to add a new song
void addSong(vector<Song> &songs)
{
    Song newSong;
    cout << "Enter song title: ";
    cin.ignore(); // Clear input buffer
    getline(cin, newSong.title);

    cout << "Enter artist: ";
    getline(cin, newSong.artist);

    cout << "Enter album: ";
    getline(cin, newSong.album);

    cout << "Enter year: ";
    cin >> newSong.year;

    cout << "Enter track number: ";
    cin >> newSong.trackNumber;

    songs.push_back(newSong);
    colorPrint("Song added successfully!\n", 32); // Green color
}

// Function to display all songs
void displaySongs(const vector<Song> &songs)
{
    if (songs.empty())
    {
        colorPrint("No songs in the library.\n", 31); // Red color
        return;
    }

    cout << left << setw(25) << "Title" << setw(20) << "Artist" << setw(20) << "Album" << setw(8) << "Year" << setw(10) << "Track" << endl;
    cout << "-----------------------------------------------------------------------" << endl;

    for (const Song &song : songs)
    {
        cout << left << setw(25) << song.title << setw(20) << song.artist << setw(20) << song.album << setw(8) << song.year << setw(10) << song.trackNumber << endl;
    }
}

// Function to search for a song by title
vector<Song> searchSongs(const vector<Song> &songs, const string &searchTerm)
{
    vector<Song> results;
    for (const Song &song : songs)
    {
        if (song.title.find(searchTerm) != string::npos)
        {
            results.push_back(song);
        }
    }
    return results;
}

// Function to remove a song
void removeSong(vector<Song> &songs)
{
    displaySongs(songs);

    if (songs.empty())
    {
        return;
    }

    cout << "Enter the title of the song to remove: ";
    string titleToRemove;
    cin.ignore(); // Clear input buffer
    getline(cin, titleToRemove);

    // Find the song to remove
    auto it = find_if(songs.begin(), songs.end(),
                      [&titleToRemove](const Song &song)
                      { return song.title == titleToRemove; });

    if (it != songs.end())
    {
        songs.erase(it);
        colorPrint("Song removed successfully!\n", 32); // Green color
    }
    else
    {
        colorPrint("Song not found.\n", 31); // Red color
    }
}

// Function to edit a song
void editSong(vector<Song> &songs)
{
    displaySongs(songs);

    if (songs.empty())
    {
        return;
    }

    cout << "Enter the title of the song to edit: ";
    string titleToEdit;
    cin.ignore();
    getline(cin, titleToEdit);

    // Find the song to edit
    auto it = find_if(songs.begin(), songs.end(),
                      [&titleToEdit](const Song &song)
                      { return song.title == titleToEdit; });

    if (it != songs.end())
    {
        cout << "Enter new title (leave blank to keep current): ";
        getline(cin, (*it).title);

        cout << "Enter new artist (leave blank to keep current): ";
        getline(cin, (*it).artist);

        cout << "Enter new album (leave blank to keep current): ";
        getline(cin, (*it).album);

        cout << "Enter new year (leave blank to keep current): ";
        string yearInput;
        getline(cin, yearInput);
        if (!yearInput.empty())
        {
            (*it).year = stoi(yearInput);
        }

        cout << "Enter new track number (leave blank to keep current): ";
        string trackNumberInput;
        getline(cin, trackNumberInput);
        if (!trackNumberInput.empty())
        {
            (*it).trackNumber = stoi(trackNumberInput);
        }

        colorPrint("Song edited successfully!\n", 32); // Green color
    }
    else
    {
        colorPrint("Song not found.\n", 31); // Red color
    }
}

// Function to display the main menu
void displayMenu()
{
    colorPrint("\nSong Management System\n", 34); // Blue color
    cout << "1. Add Song\n";
    cout << "2. Display All Songs\n";
    cout << "3. Search Songs\n";
    cout << "4. Remove Song\n";
    cout << "5. Edit Song\n";
    cout << "6. Exit\n";
    cout << "Enter your choice: ";
}

// Function to handle user input and execute commands
void handleInput(vector<Song> &songs, const string &filename)
{
    int choice;
    while (true)
    {
        displayMenu();
        cin >> choice;

        switch (choice)
        {
        case 1:
            addSong(songs);
            break;
        case 2:
            displaySongs(songs);
            break;
        case 3:
        {
            cout << "Enter search term: ";
            string searchTerm;
            cin.ignore();
            getline(cin, searchTerm);
            vector<Song> results = searchSongs(songs, searchTerm);
            displaySongs(results);
            break;
        }
        case 4:
            removeSong(songs);
            break;
        case 5:
            editSong(songs);
            break;
        case 6:
            saveSongs(filename, songs);
            colorPrint("Exiting...\n", 32); // Green color
            return;
        default:
            colorPrint("Invalid choice. Please try again.\n", 31); // Red color
        }

        // Pause execution using cin.get()
        cout << "\nPress Enter to continue...\n";
        cin.ignore(); // Clear input buffer
        cin.get();
    }
}

int main()
{
    // Set the console color for the program (ANSI escape codes)
    cout << "\033[37;40m"; // White text on black background

    // Initialize the vector of songs
    vector<Song> songs;

    // Load songs from the data file if it exists
    songs = loadSongs("songs.txt");

    // Handle user input and execute commands
    handleInput(songs, "songs.txt");

    return 0;
}